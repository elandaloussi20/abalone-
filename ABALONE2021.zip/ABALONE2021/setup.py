from setuptools import setup, find_packages


description = ('An intelligent game engine for the strategic board game Abalone.')

with open('README.md') as readme:
    long_description = readme.read()

setup(
    name='abalone',
    version='0.2',
    description=description,
    long_description=long_description,
    author='Anouar & Mustapha',
    author_email='195116@ecam.be ',
    url='https://github.com/elandaloussi20/abalone-',
    packages=find_packages(exclude=('tests*',)),
    install_requires=[
        'pyfiglet'
    ],
